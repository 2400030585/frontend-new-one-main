# Doctor Appointments UI

A React + MUI app to book and manage doctor appointments.

## Tech Stack

- React (Vite)
- @mui/material
- @mui/icons-material
- @emotion/react
- @emotion/styled
- @mui/x-date-pickers + dayjs

## Installation

```powershell
npm install
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173) in your browser.

## Features

- Book appointments with form validation
- View appointments as cards
- Cancel appointments
- Edit existing appointments
- Responsive layout (mobile-friendly)\
